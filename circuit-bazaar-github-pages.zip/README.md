# Circuit Bazaar – Adobe implementation practice store

A multi-page demo electronics store with **no analytics code**. You build the data layer, the Adobe Tags property and the Analytics setup yourself. Search engines are told not to index it.

All products and brands are fictional. No payment is taken, and the store saves your details only in your own browser.

## Pages

| Page | URL pattern | What's on it |
| --- | --- | --- |
| Home | `index.html` | Hero banner, 3 promo tiles, categories, bestsellers, deals, recently viewed |
| Category | `category.html?c=audio` | Brand, price, rating and in-stock filters, plus sort. Filters update the URL |
| Search results | `search.html?q=hush` | Same filters. Null-result page for searches like `drone` |
| Product | `product.html?sku=CB-1005` | Quantity, add to cart, buy now, wishlist, PIN code check, specs and reviews tabs |
| Out-of-stock product | `product.html?sku=CB-1015` | Back-in-stock email form |
| Cart | `cart.html` | Quantity change, remove, move to wishlist, coupons |
| Checkout: delivery | `checkout.html` | Address form with validation, standard or express delivery |
| Checkout: payment | `payment.html` | UPI, card, net banking, cash on delivery |
| Confirmation | `confirmation.html?order=CB…` | Order ID, items, total |
| Login / Register | `login.html`, `register.html` | Validation errors, marketing opt-in |
| Account | `account.html` | Profile, order history, log out |
| Wishlist | `wishlist.html` | Move to cart, remove |
| 404 | any unknown page | Not-found page |

## Things to practise tracking

- **Page views:** page name, page type, site section, breadcrumbs.
- **Internal campaigns:** home links carry `?icid=`, for example `icid=hp_hero_festive-sale`.
- **Internal search:** term, result count, null searches (try `drone`).
- **Filters and sort:** read them from the URL or from change events on `#filters` and `#sort-select`.
- **Product views:** use `data-sku` on `.pdp` and on every `.product-card`.
- **Cart:** add (from cards, the product page or buy now), remove, quantity change, move to wishlist, cart view.
- **Coupons:** apply success, invalid code, and minimum-order failure. Codes are `FESTIVE10`, `WELCOME200` and `FREESHIP`.
- **Checkout funnel:** delivery step, payment step, payment method, form errors (`[aria-invalid=true]` with the message in `#<field>-error`).
- **Purchase:** order ID in `#order-id` and `data-order-id`. Full order details are in `localStorage` under `cb_orders`.
- **User:** login, registration, logout (`index.html?logout=1`), login status from `localStorage` `cb_user`.
- **Other:** wishlist add and remove, newsletter sign-up, back-in-stock request, PIN code check, reviews tab.

Every button, form and input has a stable `id`, so you can use them in rules or code.

## Test details

- **Login:** `demo@circuitbazaar.test` with any password of 6+ characters, or register a new account.
- **Card:** `4111 1111 1111 1111`, any future expiry date, any 3-digit CVV.
- **UPI:** `name@bank`
- **PIN codes:** 110001, 122001 and 400001 give metro delivery dates.

## Adding Adobe Tags

Each page has a marked comment in `<head>`: `Your Adobe implementation goes here`. Paste your data layer declaration and Tags embed code there, in all 13 HTML files.

/* Circuit Bazaar practice store.
   No analytics or data layer code is included on purpose: add your own implementation. */
(function () {
  const CB = window.CB;
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const params = new URLSearchParams(location.search);
  const inr = n => "₹" + Math.round(n).toLocaleString("en-IN");
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const offPct = p => Math.round((1 - p.price / p.mrp) * 100);
  const bySku = sku => CB.PRODUCTS.find(p => p.sku === sku);
  const catName = id => (CB.CATEGORIES.find(c => c.id === id) || { name: "All products" }).name;

  /* ---------- storage ---------- */
  const store = {
    get(k, d) { try { const v = localStorage.getItem("cb_" + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem("cb_" + k, JSON.stringify(v)); } catch (e) {} },
    del(k) { try { localStorage.removeItem("cb_" + k); } catch (e) {} }
  };
  const getCart = () => store.get("cart", []).filter(i => bySku(i.sku));
  const setCart = c => { store.set("cart", c); updateBadges(); };
  const getWish = () => store.get("wish", []).filter(bySku);
  const setWish = w => { store.set("wish", w); updateBadges(); };
  const getUser = () => store.get("user", null);

  function addToCart(sku, qty = 1) {
    const p = bySku(sku); if (!p || p.stock === 0) return;
    const c = getCart(); const i = c.find(x => x.sku === sku);
    if (i) i.qty = Math.min(i.qty + qty, 10); else c.push({ sku, qty });
    setCart(c);
    toast(`Added ${esc(p.name)} to cart`, '<a href="cart.html">View cart</a>');
  }
  function toggleWish(sku) {
    let w = getWish(); const on = w.includes(sku);
    w = on ? w.filter(s => s !== sku) : [...w, sku]; setWish(w);
    toast(on ? "Removed from wishlist" : "Saved to wishlist", on ? "" : '<a href="wishlist.html">View wishlist</a>');
    return !on;
  }

  /* ---------- totals ---------- */
  function totals(delivery = "standard") {
    const items = getCart().map(i => ({ ...i, p: bySku(i.sku) }));
    const subtotal = items.reduce((s, i) => s + i.p.price * i.qty, 0);
    const mrp = items.reduce((s, i) => s + i.p.mrp * i.qty, 0);
    const units = items.reduce((s, i) => s + i.qty, 0);
    const code = store.get("coupon", null);
    const cp = code && CB.COUPONS[code];
    let discount = 0, freeShip = false, couponValid = false;
    if (cp && subtotal >= cp.min) { discount = cp.apply(subtotal); freeShip = !!cp.freeShip; couponValid = true; }
    let shipping = subtotal === 0 ? 0 : (subtotal >= 999 || freeShip ? 0 : 49);
    if (delivery === "express" && subtotal > 0) shipping += 99;
    const total = Math.max(subtotal - discount + shipping, 0);
    const gst = Math.round(total * 18 / 118);
    return { items, subtotal, mrp, units, savings: mrp - subtotal, code, couponValid, discount, shipping, total, gst };
  }

  /* ---------- shared UI ---------- */
  function toast(msg, extra = "") {
    let t = $("#toast");
    if (!t) { t = document.createElement("div"); t.id = "toast"; t.className = "toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
    t.innerHTML = `<span>${msg}</span>${extra}`; t.hidden = false;
    clearTimeout(toast.t); toast.t = setTimeout(() => { t.hidden = true; }, 2600);
  }
  const logoSvg = '<svg viewBox="0 0 26 26" fill="none" aria-hidden="true"><rect x="1" y="1" width="24" height="24" rx="7" fill="var(--accent)"/><path d="M7 13h4l2-5 2 10 2-5h2" stroke="var(--accent-ink)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const heart = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20s-7-4.4-9.2-9A5 5 0 0 1 12 6a5 5 0 0 1 9.2 5C19 15.6 12 20 12 20z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';

  function renderHeader() {
    const u = getUser(); const page = document.body.dataset.page; const cur = params.get("c");
    $("#header").outerHTML = `
    <div class="topstrip">Festive Sale: extra 10% off with <b>FESTIVE10</b> · Free delivery over ₹999</div>
    <header class="site-header" id="site-header">
      <div class="wrap hrow">
        <a class="logo" href="index.html">${logoSvg}Circuit Bazaar</a>
        <form class="search" action="search.html" method="get" role="search" id="search-form">
          <input id="search-input" name="q" type="search" placeholder="Search phones, earbuds, chargers…" value="${esc(params.get("q") || "")}" autocomplete="off" aria-label="Search products">
          <button type="submit" id="search-submit">Search</button>
        </form>
        <nav class="hlinks" aria-label="Account">
          <a class="hlink" id="nav-account" href="${u ? "account.html" : "login.html"}">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><circle cx="9" cy="6" r="3.2" stroke="currentColor" stroke-width="1.6"/><path d="M3 16c.8-3 3.2-4.5 6-4.5s5.2 1.5 6 4.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
            <span class="lab">${u ? "Hi, " + esc(u.name.split(" ")[0]) : "Login"}</span></a>
          <a class="hlink" id="nav-wishlist" href="wishlist.html">${heart.replace('viewBox', 'width="18" height="18" viewBox')}<span class="lab">Wishlist</span><span class="badge" id="wish-count">0</span></a>
          <a class="hlink" id="nav-cart" href="cart.html">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><path d="M2 3h2l2 9h8l2-6H5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="7" cy="15" r="1.2" fill="currentColor"/><circle cx="13" cy="15" r="1.2" fill="currentColor"/></svg>
            <span class="lab">Cart</span><span class="badge" id="cart-count">0</span></a>
        </nav>
      </div>
      <nav class="catnav" aria-label="Categories"><div class="wrap">
        <a href="category.html?c=all" ${page === "category" && (!cur || cur === "all") ? 'aria-current="page"' : ""}>All products</a>
        ${CB.CATEGORIES.map(c => `<a href="category.html?c=${c.id}" ${page === "category" && cur === c.id ? 'aria-current="page"' : ""}>${c.name}</a>`).join("")}
        <a href="category.html?c=all&amp;sort=discount">Deals</a>
      </div></nav>
    </header>`;
    updateBadges();
  }
  function updateBadges() {
    const n = getCart().reduce((s, i) => s + i.qty, 0);
    const c = $("#cart-count"); if (c) c.textContent = n;
    const w = $("#wish-count"); if (w) w.textContent = getWish().length;
  }
  function renderFooter() {
    $("#footer").outerHTML = `
    <footer class="site-footer"><div class="wrap">
      <div class="fgrid">
        <div><a class="logo" href="index.html" style="display:flex;padding:0;color:var(--ink)">${logoSvg}Circuit Bazaar</a>
          <p class="muted" style="font-size:14px;max-width:32ch">Phones, laptops, audio and wearables with GST-inclusive prices and a 1-year warranty.</p></div>
        <div><h4>Shop</h4>${CB.CATEGORIES.map(c => `<a href="category.html?c=${c.id}">${c.name}</a>`).join("")}</div>
        <div><h4>Account</h4><a href="account.html">My account</a><a href="account.html#orders">My orders</a><a href="wishlist.html">Wishlist</a><a href="cart.html">Cart</a></div>
        <div><h4>Newsletter</h4><p class="muted" style="font-size:14px;margin:0">Deals and launches, once a week.</p>
          <form class="newsletter" id="newsletter-form" novalidate>
            <input class="input" id="newsletter-email" type="email" placeholder="you@example.com" aria-label="Email address" required>
            <button class="btn primary" type="submit" id="newsletter-submit">Subscribe</button>
          </form><div class="err bad" id="newsletter-error" style="font-size:12px;margin-top:4px"></div></div>
      </div>
      <div class="fbottom"><span>© 2026 Circuit Bazaar · Practice store: no real orders or payments.</span><span>Prices in INR, inclusive of 18% GST</span></div>
    </div></footer>`;
    $("#newsletter-form").addEventListener("submit", e => {
      e.preventDefault(); const i = $("#newsletter-email");
      if (!/^\S+@\S+\.\S+$/.test(i.value.trim())) { $("#newsletter-error").textContent = "Enter a valid email address"; return; }
      $("#newsletter-error").textContent = ""; i.value = ""; toast("Subscribed to the newsletter");
    });
  }

  function card(p) {
    const wished = getWish().includes(p.sku);
    const oos = p.stock === 0;
    return `<article class="card product-card" data-sku="${p.sku}">
      <a class="thumb" href="product.html?sku=${p.sku}" style="background:var(--${p.tile})" aria-label="${esc(p.name)}">${CB.ART[p.art]}
        <span class="tag ${oos ? "oos" : ""}">${oos ? "Out of stock" : "−" + offPct(p) + "%"}</span></a>
      <button class="wish" data-wish="${p.sku}" aria-pressed="${wished}" aria-label="Save ${esc(p.name)} to wishlist">${heart}</button>
      <div class="cbody">
        <span class="brand">${p.brand}</span>
        <h3><a href="product.html?sku=${p.sku}">${esc(p.name)}</a></h3>
        <span class="hl">${p.highlights.join(" · ")}</span>
        <span class="rating"><b>★ ${p.rating}</b> (${p.reviews.toLocaleString("en-IN")})</span>
        <div class="prow"><span class="now">${inr(p.price)}</span><span class="was">${inr(p.mrp)}</span></div>
        <button class="add" data-add="${p.sku}" ${oos ? "disabled" : ""}>${oos ? "Out of stock" : "Add to cart"}</button>
      </div></article>`;
  }
  function bindCards(root = document) {
    root.addEventListener("click", e => {
      const a = e.target.closest("[data-add]"); if (a) { addToCart(a.dataset.add); return; }
      const w = e.target.closest("[data-wish]"); if (w) { w.setAttribute("aria-pressed", toggleWish(w.dataset.wish)); }
    });
  }
  const main = () => $("#main");
  const crumbs = list => `<nav class="crumbs" aria-label="Breadcrumb">${list.map((c, i) => i < list.length - 1 ? `<a href="${c[1]}">${esc(c[0])}</a><span>/</span>` : `<span aria-current="page">${esc(c[0])}</span>`).join("")}</nav>`;

  /* ---------- listing (category + search) ---------- */
  const SORTS = { popular: ["Most popular", (a, b) => b.pop - a.pop], "price-asc": ["Price: low to high", (a, b) => a.price - b.price], "price-desc": ["Price: high to low", (a, b) => b.price - a.price], discount: ["Biggest discount", (a, b) => offPct(b) - offPct(a)], rating: ["Top rated", (a, b) => b.rating - a.rating] };
  function listing({ base, title, crumb, isSearch }) {
    const brands = [...new Set(base.map(p => p.brand))].sort();
    const maxPossible = Math.max(80000, ...base.map(p => p.price));
    const st = {
      brands: (params.get("brand") || "").split(",").filter(Boolean),
      max: +params.get("max") || maxPossible,
      rating: +params.get("rating") || 0,
      instock: params.get("instock") === "1",
      sort: SORTS[params.get("sort")] ? params.get("sort") : "popular"
    };
    main().innerHTML = `${crumbs(crumb)}
      <div class="listing">
        <aside class="filters" aria-label="Filters" id="filters">
          <div class="fgroup"><h4>Brand</h4>${brands.map(b => `<label><input type="checkbox" name="brand" value="${b}" id="f-brand-${b.toLowerCase()}" ${st.brands.includes(b) ? "checked" : ""}> ${b}</label>`).join("") || '<span class="muted">No brands</span>'}</div>
          <div class="fgroup"><h4>Max price</h4><input type="range" id="f-max" min="1000" max="${maxPossible}" step="500" value="${st.max}" aria-label="Maximum price"><div class="pv" id="f-max-label">up to ${inr(st.max)}</div></div>
          <div class="fgroup"><h4>Customer rating</h4>${[0, 4, 4.3].map(r => `<label><input type="radio" name="rating" value="${r}" id="f-rating-${String(r).replace(".", "")}" ${st.rating === r ? "checked" : ""}> ${r ? r + "★ & above" : "Any rating"}</label>`).join("")}</div>
          <div class="fgroup"><h4>Availability</h4><label><input type="checkbox" id="f-instock" ${st.instock ? "checked" : ""}> In stock only</label></div>
          <button class="linkbtn" id="f-clear" type="button">Clear all filters</button>
        </aside>
        <section>
          <div class="toolbar"><div><h1>${esc(title)}</h1><span class="count" id="result-count"></span></div>
            <label style="display:flex;gap:8px;align-items:center"><span class="muted" style="font-size:13px">Sort by</span>
            <select id="sort-select">${Object.entries(SORTS).map(([k, v]) => `<option value="${k}" ${k === st.sort ? "selected" : ""}>${v[0]}</option>`).join("")}</select></label></div>
          <div class="chips" id="active-filters"></div>
          <div class="grid" id="product-grid"></div>
        </section>
      </div>`;
    function apply(pushUrl) {
      const r = base.filter(p => (!st.brands.length || st.brands.includes(p.brand)) && p.price <= st.max && p.rating >= st.rating && (!st.instock || p.stock > 0)).sort(SORTS[st.sort][1]);
      $("#result-count").textContent = r.length + (r.length === 1 ? " product" : " products");
      $("#product-grid").innerHTML = r.length ? r.map(card).join("") :
        isSearch && !base.length ? "" : `<div class="empty" style="grid-column:1/-1"><h3>No products match these filters</h3><p>Try removing a filter or raising the max price.</p></div>`;
      const chips = [...st.brands, st.max < maxPossible ? "Under " + inr(st.max) : "", st.rating ? st.rating + "★+" : "", st.instock ? "In stock" : ""].filter(Boolean);
      $("#active-filters").innerHTML = chips.map(c => `<span class="chip">${esc(c)}</span>`).join("");
      if (pushUrl) {
        const q = new URLSearchParams(location.search);
        st.brands.length ? q.set("brand", st.brands.join(",")) : q.delete("brand");
        st.max < maxPossible ? q.set("max", st.max) : q.delete("max");
        st.rating ? q.set("rating", st.rating) : q.delete("rating");
        st.instock ? q.set("instock", "1") : q.delete("instock");
        st.sort !== "popular" ? q.set("sort", st.sort) : q.delete("sort");
        history.replaceState(null, "", location.pathname + "?" + q.toString());
      }
    }
    $("#filters").addEventListener("change", e => {
      if (e.target.name === "brand") st.brands = $$('input[name=brand]:checked').map(i => i.value);
      if (e.target.name === "rating") st.rating = +e.target.value;
      if (e.target.id === "f-instock") st.instock = e.target.checked;
      if (e.target.id === "f-max") st.max = +e.target.value;
      apply(true);
    });
    $("#f-max").addEventListener("input", e => { $("#f-max-label").textContent = "up to " + inr(e.target.value); });
    $("#sort-select").addEventListener("change", e => { st.sort = e.target.value; apply(true); });
    $("#f-clear").addEventListener("click", () => { st.brands = []; st.max = maxPossible; st.rating = 0; st.instock = false; $$("#filters input[type=checkbox]").forEach(i => i.checked = false); $("#f-rating-0").checked = true; $("#f-max").value = maxPossible; $("#f-max-label").textContent = "up to " + inr(maxPossible); apply(true); });
    apply(false); bindCards(main());
  }

  /* ---------- pages ---------- */
  const pages = {};

  pages.home = () => {
    const best = [...CB.PRODUCTS].sort((a, b) => b.pop - a.pop).slice(0, 8);
    const deals = [...CB.PRODUCTS].filter(p => p.stock > 0).sort((a, b) => offPct(b) - offPct(a)).slice(0, 4);
    const recent = store.get("recent", []).map(bySku).filter(Boolean).slice(0, 4);
    const art = { phones: "phone", laptops: "laptop", audio: "audio", wearables: "watch", accessories: "power" };
    const tiles = ["tile1", "tile2", "tile3", "tile4", "tile1"];
    main().innerHTML = `
      <section class="hero">
        <div class="deal" id="hero-banner">
          <div><span class="eyebrow">Festive Sale · ends 31 Oct</span><h1>Up to 35% off audio &amp; wearables</h1></div>
          <p>Prices include GST. No-cost EMI on orders above ₹3,000 with select cards.</p>
          <a class="btn primary" id="hero-cta" href="category.html?c=audio&amp;sort=discount&amp;icid=hp_hero_festive-sale">Shop the sale</a>
          <svg class="wave" viewBox="0 0 260 120" fill="none" aria-hidden="true"><path d="M0 60 Q20 10 40 60 T80 60 T120 60 T160 60 T200 60 T240 60 T280 60" stroke="var(--accent)" stroke-width="3"/><path d="M0 80 Q20 40 40 80 T80 80 T120 80 T160 80 T200 80 T240 80" stroke="var(--bg)" stroke-width="2"/></svg>
        </div>
        <div class="promo-stack">
          <a class="promo" id="promo-laptops" href="category.html?c=laptops&amp;icid=hp_tile_laptops"><div><b>Laptops from ₹21,499</b><span>Work, study and gaming</span></div><span class="code">Shop</span></a>
          <a class="promo" id="promo-welcome" href="category.html?c=all&amp;icid=hp_tile_welcome"><div><b>₹200 off your first order</b><span>On orders above ₹999</span></div><span class="code">WELCOME200</span></a>
          <a class="promo" id="promo-wearables" href="category.html?c=wearables&amp;icid=hp_tile_wearables"><div><b>Smartwatches from ₹1,499</b><span>Fitness, calls and GPS</span></div><span class="code">Shop</span></a>
        </div>
      </section>
      <div class="section-head"><h2>Shop by category</h2></div>
      <div class="cats">${CB.CATEGORIES.map((c, i) => `<a class="cat-tile" href="category.html?c=${c.id}" style="background:var(--${tiles[i]})">${CB.ART[art[c.id]]}<b>${c.name}</b><span>${CB.PRODUCTS.filter(p => p.cat === c.id).length} products</span></a>`).join("")}</div>
      <div class="section-head"><h2>Bestsellers</h2><a href="category.html?c=all">See all</a></div>
      <div class="grid" id="bestsellers">${best.map(card).join("")}</div>
      <div class="section-head"><h2>Biggest discounts</h2><a href="category.html?c=all&amp;sort=discount">See all deals</a></div>
      <div class="grid" id="deals">${deals.map(card).join("")}</div>
      ${recent.length ? `<div class="section-head"><h2>Recently viewed</h2></div><div class="grid" id="recently-viewed">${recent.map(card).join("")}</div>` : ""}
      <div class="perks">
        <div class="perk"><b>Free delivery over ₹999</b><span>Metro cities in 1–2 days</span></div>
        <div class="perk"><b>No-cost EMI</b><span>On orders above ₹3,000</span></div>
        <div class="perk"><b>7-day replacement</b><span>On manufacturing defects</span></div>
        <div class="perk"><b>1-year warranty</b><span>On every device</span></div>
      </div>`;
    bindCards(main());
  };

  pages.category = () => {
    const c = params.get("c") || "all";
    const valid = c === "all" || CB.CATEGORIES.some(x => x.id === c);
    if (!valid) return notFound("We couldn't find that category.");
    const base = c === "all" ? CB.PRODUCTS : CB.PRODUCTS.filter(p => p.cat === c);
    document.title = catName(c) + " | Circuit Bazaar";
    listing({ base, title: catName(c), crumb: [["Home", "index.html"], [catName(c), ""]] });
  };

  pages.search = () => {
    const q = (params.get("q") || "").trim();
    const terms = q.toLowerCase().split(/\s+/).filter(Boolean);
    const base = CB.PRODUCTS.filter(p => terms.length && terms.every(t => (p.name + " " + p.brand + " " + p.cat + " " + catName(p.cat) + " " + p.highlights.join(" ")).toLowerCase().includes(t)));
    document.title = (q ? `Search: ${q}` : "Search") + " | Circuit Bazaar";
    if (!base.length) {
      main().innerHTML = `${crumbs([["Home", "index.html"], ["Search", ""]])}
        <div class="empty" id="no-results"><h3>${q ? `No results for “${esc(q)}”` : "Type something to search"}</h3>
        <p>Check the spelling, or try a broader word like “earbuds”, “charger” or “watch”.</p></div>
        <div class="section-head"><h2>Popular right now</h2></div>
        <div class="grid">${[...CB.PRODUCTS].sort((a, b) => b.pop - a.pop).slice(0, 4).map(card).join("")}</div>`;
      bindCards(main()); return;
    }
    listing({ base, title: `Results for “${q}”`, crumb: [["Home", "index.html"], ["Search", ""]], isSearch: true });
  };

  pages.product = () => {
    const p = bySku(params.get("sku"));
    if (!p) return notFound("We couldn't find that product.");
    document.title = p.name + " | Circuit Bazaar";
    store.set("recent", [p.sku, ...store.get("recent", []).filter(s => s !== p.sku)].slice(0, 8));
    let qty = 1;
    const oos = p.stock === 0;
    const stockLine = oos ? '<span class="bad">Out of stock</span>' : p.stock < 10 ? `<span class="warn">Only ${p.stock} left in stock</span>` : '<span class="good">In stock</span>';
    const related = CB.PRODUCTS.filter(x => x.cat === p.cat && x.sku !== p.sku).slice(0, 4);
    const reviews = [
      ["Rahul M.", 5, "Worth every rupee", "Delivered in two days and works exactly as described."],
      ["Sneha K.", 4, "Good value", "Build quality is solid. The box could have been packed better."],
      ["Arjun P.", 4, "Happy with it", "Battery life matches the listing. Would buy again in the sale."]
    ];
    main().innerHTML = `${crumbs([["Home", "index.html"], [catName(p.cat), "category.html?c=" + p.cat], [p.name, ""]])}
      <div class="pdp" data-sku="${p.sku}">
        <div class="gallery" style="background:var(--${p.tile})">${CB.ART[p.art]}<span class="tag ${oos ? "oos" : ""}">${oos ? "Out of stock" : "−" + offPct(p) + "%"}</span></div>
        <div class="pinfo">
          <span class="brand">${p.brand} · SKU ${p.sku}</span>
          <h1 id="product-name">${esc(p.name)}</h1>
          <span class="rating"><b>★ ${p.rating}</b> · ${p.reviews.toLocaleString("en-IN")} ratings · <a href="#reviews" id="see-reviews">See reviews</a></span>
          <div class="prow" style="padding:0"><span class="now" id="product-price">${inr(p.price)}</span><span class="was">MRP ${inr(p.mrp)}</span><span class="off">${offPct(p)}% off</span></div>
          <span class="muted" style="font-size:13px">Inclusive of all taxes</span>
          ${p.price >= 3000 ? `<div class="emi">No-cost EMI from ${inr(Math.ceil(p.price / 6))}/month for 6 months</div>` : ""}
          <p style="margin:0">${esc(p.desc)}</p>
          <div>${stockLine}</div>
          ${oos ? `<div class="panel" style="padding:14px"><b>Get notified when it's back</b>
              <form class="pincode" id="notify-form" style="margin-top:8px" novalidate><input class="input" id="notify-email" type="email" placeholder="you@example.com" aria-label="Email for back-in-stock alert"><button class="btn" id="notify-submit">Notify me</button></form></div>` :
            `<div class="qtyrow"><span class="muted">Quantity</span><div class="qty"><button id="qty-minus" aria-label="Decrease quantity">−</button><span id="qty-value">1</span><button id="qty-plus" aria-label="Increase quantity">+</button></div></div>
             <div class="actions"><button class="btn primary" id="add-to-cart">Add to cart</button><button class="btn" id="buy-now">Buy now</button>
             <button class="btn wishbig" id="pdp-wish" aria-pressed="${getWish().includes(p.sku)}">${getWish().includes(p.sku) ? "Saved" : "Wishlist"}</button></div>`}
          <div class="panel" style="padding:14px"><b>Check delivery</b>
            <form class="pincode" id="pincode-form" style="margin-top:8px" novalidate><input class="input" id="pincode-input" inputmode="numeric" maxlength="6" placeholder="Enter 6-digit PIN code" aria-label="PIN code"><button class="btn" id="pincode-check">Check</button></form>
            <div id="pincode-result" style="font-size:14px;margin-top:8px"></div></div>
        </div>
      </div>
      <div class="tabs" role="tablist">
        <button role="tab" id="tab-specs" aria-selected="true" aria-controls="panel-specs">Specifications</button>
        <button role="tab" id="tab-reviews" aria-selected="false" aria-controls="reviews">Reviews (${p.reviews.toLocaleString("en-IN")})</button>
      </div>
      <div id="panel-specs" role="tabpanel"><table class="sheet">${Object.entries(p.specs).map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`).join("")}<tr><td>Warranty</td><td>1 year manufacturer</td></tr></table></div>
      <div id="reviews" role="tabpanel" hidden>${reviews.map(r => `<div class="review"><span class="stars">${"★".repeat(r[1])}${"☆".repeat(5 - r[1])}</span><b>${r[2]}</b><p style="margin:4px 0">${r[3]}</p><span class="muted" style="font-size:13px">${r[0]} · Verified buyer</span></div>`).join("")}
        <p class="muted" style="font-size:13px">Sample reviews for the practice store.</p></div>
      ${related.length ? `<div class="section-head"><h2>Similar products</h2></div><div class="grid" id="related-products">${related.map(card).join("")}</div>` : ""}`;
    bindCards(main());
    const tabs = (show) => { $("#tab-specs").setAttribute("aria-selected", show === "specs"); $("#tab-reviews").setAttribute("aria-selected", show === "reviews"); $("#panel-specs").hidden = show !== "specs"; $("#reviews").hidden = show !== "reviews"; };
    $("#tab-specs").onclick = () => tabs("specs"); $("#tab-reviews").onclick = () => tabs("reviews");
    $("#see-reviews").onclick = e => { e.preventDefault(); tabs("reviews"); $("#reviews").scrollIntoView({ behavior: "smooth" }); };
    if (!oos) {
      $("#qty-minus").onclick = () => { qty = Math.max(1, qty - 1); $("#qty-value").textContent = qty; };
      $("#qty-plus").onclick = () => { qty = Math.min(10, Math.min(p.stock, qty + 1)); $("#qty-value").textContent = qty; };
      $("#add-to-cart").onclick = () => addToCart(p.sku, qty);
      $("#buy-now").onclick = () => { addToCart(p.sku, qty); location.href = "cart.html"; };
      $("#pdp-wish").onclick = e => { const on = toggleWish(p.sku); e.currentTarget.setAttribute("aria-pressed", on); e.currentTarget.textContent = on ? "Saved" : "Wishlist"; };
    } else {
      $("#notify-form").onsubmit = e => { e.preventDefault(); if (/^\S+@\S+\.\S+$/.test($("#notify-email").value)) { toast("We'll email you when it's back"); $("#notify-email").value = ""; } else toast("Enter a valid email address"); };
    }
    $("#pincode-form").onsubmit = e => {
      e.preventDefault(); const v = $("#pincode-input").value.trim(); const out = $("#pincode-result");
      if (!/^[1-9][0-9]{5}$/.test(v)) { out.innerHTML = '<span class="bad">Enter a valid 6-digit PIN code</span>'; return; }
      const metro = /^(11|12|40|56|60|70|50|41)/.test(v); const d = new Date(); d.setDate(d.getDate() + (metro ? 2 : 5));
      out.innerHTML = `<span class="good">Delivery by ${d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })}</span> to ${v}${p.price >= 999 ? " · Free delivery" : ""}`;
    };
  };

  pages.cart = () => {
    function render() {
      const t = totals();
      if (!t.items.length) {
        main().innerHTML = `${crumbs([["Home", "index.html"], ["Cart", ""]])}<div class="empty" id="empty-cart"><h3>Your cart is empty</h3><p>Browse the bestsellers or your wishlist to add something.</p><a class="btn primary" href="index.html">Continue shopping</a></div>`;
        return;
      }
      const left = 999 - t.subtotal;
      main().innerHTML = `${crumbs([["Home", "index.html"], ["Cart", ""]])}
        <h1 style="margin:0 0 16px">Your cart <span class="muted" style="font-size:16px;font-family:var(--mono)">${t.units} items</span></h1>
        <div class="two">
          <section class="panel" style="padding:4px 20px" id="cart-items">
            ${t.items.map(i => `<div class="line-item" data-sku="${i.sku}">
              <a class="mini" href="product.html?sku=${i.sku}" style="background:var(--${i.p.tile})">${CB.ART[i.p.art]}</a>
              <div><span class="brand">${i.p.brand}</span><h3><a href="product.html?sku=${i.sku}">${esc(i.p.name)}</a></h3>
                <div class="qty"><button data-dec="${i.sku}" aria-label="Decrease quantity">−</button><span>${i.qty}</span><button data-inc="${i.sku}" aria-label="Increase quantity">+</button></div>
                <div class="li-actions"><button class="linkbtn" data-remove="${i.sku}">Remove</button><button class="linkbtn" data-save="${i.sku}">Move to wishlist</button></div></div>
              <div class="li-price"><b>${inr(i.p.price * i.qty)}</b><span class="was">${inr(i.p.mrp * i.qty)}</span></div>
            </div>`).join("")}
          </section>
          <aside class="panel summary" id="order-summary">
            <h2>Order summary</h2>
            ${left > 0 ? `<span class="muted" style="font-size:13px">Add ${inr(left)} more for free delivery</span><div class="meter"><i style="width:${Math.min(100, t.subtotal / 999 * 100)}%"></i></div>` : `<span class="good" style="font-size:13px">You get free delivery</span>`}
            <div class="sline"><span>Price (${t.units} items)</span><span>${inr(t.mrp)}</span></div>
            <div class="sline good"><span>Discount on MRP</span><span>−${inr(t.savings)}</span></div>
            ${t.couponValid ? `<div class="sline good"><span>Coupon ${t.code}</span><span>−${inr(t.discount)}</span></div>` : ""}
            <div class="sline"><span>Delivery</span><span>${t.shipping ? inr(t.shipping) : "Free"}</span></div>
            <div class="sline total"><span>Total</span><span id="cart-total">${inr(t.total)}</span></div>
            <span class="muted" style="font-size:12px">Includes ${inr(t.gst)} GST</span>
            <form class="coupon" id="coupon-form" novalidate><input class="input" id="coupon-input" placeholder="Coupon code" aria-label="Coupon code" value="${t.code || ""}"><button class="btn" id="coupon-apply">${t.code ? "Change" : "Apply"}</button></form>
            <div id="coupon-msg" style="font-size:13px">${t.code ? (t.couponValid ? `<span class="good">${t.code} applied: ${CB.COUPONS[t.code].label}</span> <button class="linkbtn" id="coupon-remove" type="button">Remove</button>` : `<span class="warn">${t.code} needs a subtotal of ${inr(CB.COUPONS[t.code].min)}</span> <button class="linkbtn" id="coupon-remove" type="button">Remove</button>`) : ""}</div>
            <div class="coupon-list">Try: <span><code>FESTIVE10</code> · <code>WELCOME200</code> · <code>FREESHIP</code></span></div>
            <a class="btn primary block" id="proceed-checkout" href="checkout.html">Proceed to checkout</a>
            ${getUser() ? "" : '<span class="muted" style="font-size:13px;text-align:center">Have an account? <a href="login.html?next=checkout.html" id="cart-login">Log in</a> for faster checkout</span>'}
          </aside>
        </div>`;
      $("#coupon-form").onsubmit = e => {
        e.preventDefault(); const code = $("#coupon-input").value.trim().toUpperCase();
        if (!code) return;
        if (!CB.COUPONS[code]) { $("#coupon-msg").innerHTML = `<span class="bad">“${esc(code)}” is not a valid coupon</span>`; return; }
        store.set("coupon", code); render(); toast(`Coupon ${code} applied`);
      };
      const rm = $("#coupon-remove"); if (rm) rm.onclick = () => { store.del("coupon"); render(); };
    }
    main().addEventListener("click", e => {
      const b = e.target.closest("button"); if (!b) return;
      let c = getCart();
      if (b.dataset.inc) { const i = c.find(x => x.sku === b.dataset.inc); i.qty = Math.min(10, i.qty + 1); setCart(c); render(); }
      if (b.dataset.dec) { const i = c.find(x => x.sku === b.dataset.dec); i.qty -= 1; if (i.qty <= 0) c = c.filter(x => x !== i); setCart(c); render(); }
      if (b.dataset.remove) { setCart(c.filter(x => x.sku !== b.dataset.remove)); render(); toast("Removed from cart"); }
      if (b.dataset.save) { setCart(c.filter(x => x.sku !== b.dataset.save)); if (!getWish().includes(b.dataset.save)) setWish([...getWish(), b.dataset.save]); render(); toast("Moved to wishlist"); }
    });
    render();
  };

  const STATES = ["Andhra Pradesh", "Assam", "Bihar", "Delhi", "Gujarat", "Haryana", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Punjab", "Rajasthan", "Tamil Nadu", "Telangana", "Uttar Pradesh", "West Bengal"];
  function validate(form, rules) {
    let ok = true;
    for (const [id, [test, msg]] of Object.entries(rules)) {
      const el = $("#" + id, form); const bad = !test(el.value.trim());
      el.setAttribute("aria-invalid", bad); const err = $("#" + id + "-error", form); if (err) err.textContent = bad ? msg : "";
      if (bad) ok = false;
    }
    return ok;
  }
  const field = (id, label, attrs = "", full = false) => `<div class="field ${full ? "full" : ""}"><label for="${id}">${label}</label><input class="input" id="${id}" name="${id}" ${attrs}><span class="err" id="${id}-error"></span></div>`;
  const summaryBox = (t, title = "Order summary") => `<aside class="panel summary" id="order-summary"><h2>${title}</h2>
      ${t.items.map(i => `<div class="sline" style="font-size:14px"><span>${esc(i.p.name)} × ${i.qty}</span><span>${inr(i.p.price * i.qty)}</span></div>`).join("")}
      <div class="sline" style="border-top:1px solid var(--line);padding-top:8px"><span>Subtotal</span><span>${inr(t.subtotal)}</span></div>
      ${t.couponValid ? `<div class="sline good"><span>Coupon ${t.code}</span><span>−${inr(t.discount)}</span></div>` : ""}
      <div class="sline"><span>Delivery</span><span>${t.shipping ? inr(t.shipping) : "Free"}</span></div>
      <div class="sline total"><span>Total</span><span>${inr(t.total)}</span></div><span class="muted" style="font-size:12px">Includes ${inr(t.gst)} GST</span></aside>`;
  const stepper = n => `<div class="steps" aria-label="Checkout steps">${["Cart", "Delivery", "Payment", "Confirmation"].map((s, i) => `<span ${i === n ? 'aria-current="step"' : ""} class="${i < n ? "done" : ""}">${i < n ? "✓ " : ""}${s}</span>`).join("")}</div>`;

  pages.checkout = () => {
    if (!getCart().length) { location.replace("cart.html"); return; }
    const u = getUser() || {}; const saved = store.get("checkout", {});
    const render = () => {
      const a = saved.address || {};
      const t = totals(saved.delivery || "standard");
      main().innerHTML = `${crumbs([["Home", "index.html"], ["Cart", "cart.html"], ["Delivery", ""]])}${stepper(1)}
      <div class="two"><form class="panel" id="delivery-form" novalidate>
        <h1 style="margin:0 0 16px;font-size:26px">Delivery details</h1>
        ${u.email ? "" : '<div class="note" style="margin-bottom:14px">Checking out as a guest. <a href="login.html?next=checkout.html" id="checkout-login">Log in</a> to use your saved details.</div>'}
        <div class="form">
          ${field("full-name", "Full name", `autocomplete="name" value="${esc(a.name || u.name || "")}"`)}
          ${field("mobile", "Mobile number", `inputmode="numeric" maxlength="10" autocomplete="tel-national" value="${esc(a.mobile || u.mobile || "")}"`)}
          ${field("email", "Email", `type="email" autocomplete="email" value="${esc(a.email || u.email || "")}"`, true)}
          ${field("address", "Address", `autocomplete="street-address" placeholder="House no., street, area" value="${esc(a.address || "")}"`, true)}
          ${field("city", "City", `autocomplete="address-level2" value="${esc(a.city || "")}"`)}
          <div class="field"><label for="state">State</label><select class="input" id="state" name="state"><option value="">Select state</option>${STATES.map(s => `<option ${a.state === s ? "selected" : ""}>${s}</option>`).join("")}</select><span class="err" id="state-error"></span></div>
          ${field("pincode", "PIN code", `inputmode="numeric" maxlength="6" autocomplete="postal-code" value="${esc(a.pincode || "")}"`)}
        </div>
        <h2 style="font-size:20px;margin:24px 0 12px">Delivery speed</h2>
        <div class="options">
          <label class="option"><input type="radio" name="delivery" id="delivery-standard" value="standard" ${saved.delivery !== "express" ? "checked" : ""}><div><b>Standard · 3–5 days</b><span>Free over ₹999, else ₹49</span></div></label>
          <label class="option"><input type="radio" name="delivery" id="delivery-express" value="express" ${saved.delivery === "express" ? "checked" : ""}><div><b>Express · next day</b><span>₹99 extra, metro cities only</span></div></label>
        </div>
        <button class="btn primary block" style="margin-top:20px" type="submit" id="continue-payment">Continue to payment</button>
      </form>${summaryBox(t)}</div>`;
      $$("input[name=delivery]").forEach(r => r.onchange = () => { saved.delivery = r.value; collect(); store.set("checkout", saved); render(); });
      $("#delivery-form").onsubmit = e => {
        e.preventDefault(); const f = e.target;
        const ok = validate(f, {
          "full-name": [v => v.length >= 2, "Enter your full name"],
          mobile: [v => /^[6-9]\d{9}$/.test(v), "Enter a valid 10-digit mobile number"],
          email: [v => /^\S+@\S+\.\S+$/.test(v), "Enter a valid email address"],
          address: [v => v.length >= 8, "Enter your full address"],
          city: [v => v.length >= 2, "Enter your city"],
          state: [v => !!v, "Select your state"],
          pincode: [v => /^[1-9]\d{5}$/.test(v), "Enter a valid 6-digit PIN code"]
        });
        if (!ok) { const first = $("[aria-invalid=true]", f); if (first) first.focus(); return; }
        collect(); saved.delivery = $("input[name=delivery]:checked").value; store.set("checkout", saved); location.href = "payment.html";
      };
    };
    function collect() { const g = id => ($("#" + id) || {}).value || ""; saved.address = { name: g("full-name").trim(), mobile: g("mobile").trim(), email: g("email").trim(), address: g("address").trim(), city: g("city").trim(), state: g("state"), pincode: g("pincode").trim() }; }
    render();
  };

  pages.payment = () => {
    const saved = store.get("checkout", {});
    if (!getCart().length) { location.replace("cart.html"); return; }
    if (!saved.address) { location.replace("checkout.html"); return; }
    const a = saved.address;
    const render = method => {
      const t = totals(saved.delivery);
      const cod = method === "cod" ? 29 : 0;
      main().innerHTML = `${crumbs([["Home", "index.html"], ["Cart", "cart.html"], ["Delivery", "checkout.html"], ["Payment", ""]])}${stepper(2)}
      <div class="two"><form class="panel" id="payment-form" novalidate>
        <h1 style="margin:0 0 6px;font-size:26px">Payment</h1>
        <p class="muted" style="margin:0 0 16px;font-size:14px">Delivering to ${esc(a.name)}, ${esc(a.city)} ${esc(a.pincode)} · <a href="checkout.html" id="change-address">Change</a></p>
        <div class="options">
          <label class="option"><input type="radio" name="method" id="pay-upi" value="upi" ${method === "upi" ? "checked" : ""}><div><b>UPI</b><span>Pay with any UPI app</span></div></label>
          ${method === "upi" ? `<div class="subform">${field("upi-id", "UPI ID", 'placeholder="name@bank"')}</div>` : ""}
          <label class="option"><input type="radio" name="method" id="pay-card" value="card" ${method === "card" ? "checked" : ""}><div><b>Credit or debit card</b><span>Visa, Mastercard, RuPay</span></div></label>
          ${method === "card" ? `<div class="subform"><div class="form">${field("card-number", "Card number", 'inputmode="numeric" autocomplete="off" placeholder="4111 1111 1111 1111"', true)}${field("card-expiry", "Expiry (MM/YY)", 'autocomplete="off" placeholder="12/28"')}${field("card-cvv", "CVV", 'inputmode="numeric" maxlength="4" autocomplete="off" placeholder="123"')}</div>
            <div class="note">Practice store: use test numbers like 4111 1111 1111 1111. Card details are checked for format only and never saved.</div></div>` : ""}
          <label class="option"><input type="radio" name="method" id="pay-netbanking" value="netbanking" ${method === "netbanking" ? "checked" : ""}><div><b>Net banking</b><span>All major banks</span></div></label>
          ${method === "netbanking" ? `<div class="subform"><div class="field"><label for="bank">Bank</label><select class="input" id="bank"><option value="">Select bank</option><option>Bharat Bank</option><option>Coastal Bank</option><option>Northern Trust Bank</option><option>Union Cooperative Bank</option></select><span class="err" id="bank-error"></span></div></div>` : ""}
          <label class="option"><input type="radio" name="method" id="pay-cod" value="cod" ${method === "cod" ? "checked" : ""}><div><b>Cash on delivery</b><span>₹29 handling fee</span></div></label>
        </div>
        <button class="btn primary block" style="margin-top:20px" type="submit" id="place-order">Place order · ${inr(t.total + cod)}</button>
        <p class="muted" style="font-size:12px;text-align:center;margin:8px 0 0">No money is taken. This is a practice store.</p>
      </form>${summaryBox({ ...t, shipping: t.shipping + cod, total: t.total + cod, gst: Math.round((t.total + cod) * 18 / 118) })}</div>`;
      $$("input[name=method]").forEach(r => r.onchange = () => render(r.value));
      $("#payment-form").onsubmit = e => {
        e.preventDefault(); const f = e.target; let ok = true;
        if (method === "upi") ok = validate(f, { "upi-id": [v => /^[\w.-]{2,}@[a-z]{2,}$/i.test(v), "Enter a UPI ID like name@bank"] });
        if (method === "card") ok = validate(f, {
          "card-number": [v => /^\d{16}$/.test(v.replace(/\s/g, "")), "Enter a 16-digit card number"],
          "card-expiry": [v => { const m = v.match(/^(0[1-9]|1[0-2])\/(\d{2})$/); if (!m) return false; const now = new Date(), yy = now.getFullYear() % 100, mm = now.getMonth() + 1; return +m[2] > yy || (+m[2] === yy && +m[1] >= mm); }, "Enter a future expiry date as MM/YY"],
          "card-cvv": [v => /^\d{3,4}$/.test(v), "Enter the 3 or 4 digit CVV"]
        });
        if (method === "netbanking") ok = validate(f, { bank: [v => !!v, "Select your bank"] });
        if (!ok) return;
        const id = "CB" + Date.now().toString().slice(-8);
        const final = { ...t, shipping: t.shipping + cod, total: t.total + cod };
        const order = { id, date: new Date().toISOString(), items: t.items.map(i => ({ sku: i.sku, name: i.p.name, price: i.p.price, qty: i.qty })), subtotal: t.subtotal, discount: t.discount, coupon: t.couponValid ? t.code : null, shipping: final.shipping, total: final.total, gst: Math.round(final.total * 18 / 118), payment: { upi: "UPI", card: "Card", netbanking: "Net banking", cod: "Cash on delivery" }[method], delivery: saved.delivery || "standard", city: a.city, state: a.state, email: a.email };
        store.set("orders", [order, ...store.get("orders", [])]);
        store.set("cart", []); store.del("coupon"); store.del("checkout");
        location.href = "confirmation.html?order=" + id;
      };
    };
    render("upi");
  };

  pages.confirmation = () => {
    const o = store.get("orders", []).find(x => x.id === params.get("order"));
    if (!o) return notFound("We couldn't find that order.");
    const eta = new Date(o.date); eta.setDate(eta.getDate() + (o.delivery === "express" ? 1 : 4));
    main().innerHTML = `${stepper(3)}<div class="panel done-box" id="order-confirmation" data-order-id="${o.id}">
      <div class="tick">✓</div><h1 style="margin:0;font-size:32px">Thank you, your order is placed</h1>
      <p class="muted" style="margin:0">Order <code class="oid" id="order-id">${o.id}</code> · ${inr(o.total)} · ${esc(o.payment)}</p>
      <p style="margin:0">Expected delivery by <b>${eta.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}</b> to ${esc(o.city)}.</p>
      <table class="sheet" style="max-width:520px;text-align:left">${o.items.map(i => `<tr><td>${esc(i.name)} × ${i.qty}</td><td>${inr(i.price * i.qty)}</td></tr>`).join("")}
        ${o.coupon ? `<tr><td>Coupon ${o.coupon}</td><td>−${inr(o.discount)}</td></tr>` : ""}<tr><td>Delivery</td><td>${o.shipping ? inr(o.shipping) : "Free"}</td></tr><tr><td><b>Total</b></td><td><b>${inr(o.total)}</b></td></tr></table>
      <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center"><a class="btn primary" href="index.html">Continue shopping</a><a class="btn" href="account.html#orders">View my orders</a></div></div>`;
  };

  pages.login = () => {
    if (getUser()) { location.replace(params.get("next") || "account.html"); return; }
    main().innerHTML = `<div class="auth panel"><h1>Log in</h1><p class="muted" style="margin:0 0 18px">New here? <a href="register.html${params.get("next") ? "?next=" + encodeURIComponent(params.get("next")) : ""}" id="go-register">Create an account</a></p>
      <form id="login-form" novalidate><div class="form">${field("login-email", "Email", 'type="email" autocomplete="email"')}${field("login-password", "Password", 'type="password" autocomplete="current-password"')}</div>
      <button class="btn primary block" style="margin-top:16px" id="login-submit">Log in</button></form>
      <div class="note" style="margin-top:14px">Practice store: log in with any account you registered here, or use <b>demo@circuitbazaar.test</b> with any password of 6+ characters.</div></div>`;
    $("#login-form").onsubmit = e => {
      e.preventDefault(); const f = e.target;
      if (!validate(f, { "login-email": [v => /^\S+@\S+\.\S+$/.test(v), "Enter a valid email address"], "login-password": [v => v.length >= 6, "Password must be at least 6 characters"] })) return;
      const email = $("#login-email").value.trim().toLowerCase(); const users = store.get("users", {});
      if (email !== "demo@circuitbazaar.test" && !users[email]) { $("#login-email-error").textContent = "No account with this email. Create one first."; $("#login-email").setAttribute("aria-invalid", "true"); return; }
      store.set("user", users[email] || { name: "Demo Shopper", email, mobile: "" });
      location.href = params.get("next") || "account.html";
    };
  };

  pages.register = () => {
    main().innerHTML = `<div class="auth panel"><h1>Create account</h1><p class="muted" style="margin:0 0 18px">Already registered? <a href="login.html" id="go-login">Log in</a></p>
      <form id="register-form" novalidate><div class="form">${field("reg-name", "Full name", 'autocomplete="name"')}${field("reg-email", "Email", 'type="email" autocomplete="email"')}${field("reg-mobile", "Mobile number", 'inputmode="numeric" maxlength="10" autocomplete="tel-national"')}${field("reg-password", "Password", 'type="password" autocomplete="new-password"')}
      <label style="display:flex;gap:8px;font-size:14px"><input type="checkbox" id="reg-marketing"> Send me deals by email</label></div>
      <button class="btn primary block" style="margin-top:16px" id="register-submit">Create account</button></form>
      <div class="note" style="margin-top:14px">Practice store: your details stay in this browser only. Passwords are not saved.</div></div>`;
    $("#register-form").onsubmit = e => {
      e.preventDefault(); const f = e.target;
      const users = store.get("users", {});
      if (!validate(f, {
        "reg-name": [v => v.length >= 2, "Enter your full name"],
        "reg-email": [v => /^\S+@\S+\.\S+$/.test(v) && !users[v.toLowerCase()], users[$("#reg-email").value.trim().toLowerCase()] ? "An account with this email already exists" : "Enter a valid email address"],
        "reg-mobile": [v => /^[6-9]\d{9}$/.test(v), "Enter a valid 10-digit mobile number"],
        "reg-password": [v => v.length >= 6, "Use at least 6 characters"]
      })) return;
      const u = { name: $("#reg-name").value.trim(), email: $("#reg-email").value.trim().toLowerCase(), mobile: $("#reg-mobile").value.trim(), marketing: $("#reg-marketing").checked };
      users[u.email] = u; store.set("users", users); store.set("user", u);
      location.href = (params.get("next") || "account.html") + (params.get("next") ? "" : "?welcome=1");
    };
  };

  pages.account = () => {
    const u = getUser(); if (!u) { location.replace("login.html?next=account.html"); return; }
    const orders = store.get("orders", []);
    main().innerHTML = `${crumbs([["Home", "index.html"], ["My account", ""]])}
      ${params.get("welcome") ? '<div class="note" style="margin-bottom:16px" id="welcome-msg">Welcome to Circuit Bazaar! Use <b>WELCOME200</b> for ₹200 off your first order.</div>' : ""}
      <div class="two"><section>
        <h1 style="margin:0 0 16px">Hi, ${esc(u.name.split(" ")[0])}</h1>
        <h2 id="orders" style="font-size:22px">My orders</h2>
        <div class="orders">${orders.length ? orders.map(o => `<div class="order"><header><b>Order ${o.id}</b><span class="muted">${new Date(o.date).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</span></header>
          <span>${o.items.map(i => esc(i.name) + " × " + i.qty).join(", ")}</span><span class="muted" style="font-size:14px">${inr(o.total)} · ${esc(o.payment)} · <span class="good">Confirmed</span></span></div>`).join("") : '<div class="empty"><h3>No orders yet</h3><p><a href="index.html">Start shopping</a></p></div>'}</div>
      </section>
      <aside class="panel summary"><h2>Profile</h2><div class="sline"><span class="muted">Name</span><span>${esc(u.name)}</span></div><div class="sline"><span class="muted">Email</span><span>${esc(u.email)}</span></div>
        ${u.mobile ? `<div class="sline"><span class="muted">Mobile</span><span>${esc(u.mobile)}</span></div>` : ""}
        <a class="btn block" href="wishlist.html">My wishlist (${getWish().length})</a><button class="btn block" id="logout">Log out</button></aside></div>`;
    $("#logout").onclick = () => { store.del("user"); location.href = "index.html?logout=1"; };
  };

  pages.wishlist = () => {
    const render = () => {
      const w = getWish().map(bySku);
      main().innerHTML = `${crumbs([["Home", "index.html"], ["Wishlist", ""]])}<h1 style="margin:0 0 16px">Wishlist <span class="muted" style="font-size:16px;font-family:var(--mono)">${w.length} items</span></h1>
        ${w.length ? `<div class="grid" id="wishlist-grid">${w.map(card).join("")}</div>` : '<div class="empty" id="empty-wishlist"><h3>Your wishlist is empty</h3><p>Tap the heart on any product to save it here.</p><a class="btn primary" href="index.html">Browse products</a></div>'}`;
    };
    main().addEventListener("click", e => {
      const a = e.target.closest("[data-add]"); if (a) { addToCart(a.dataset.add); setWish(getWish().filter(s => s !== a.dataset.add)); render(); return; }
      const w = e.target.closest("[data-wish]"); if (w) { toggleWish(w.dataset.wish); render(); }
    });
    render();
  };

  pages.notfound = () => notFound("The page you're looking for doesn't exist.");
  function notFound(msg) {
    document.title = "Page not found | Circuit Bazaar";
    main().innerHTML = `<div class="empty" id="not-found" style="margin-top:20px"><h3>Page not found</h3><p>${esc(msg)}</p><a class="btn primary" href="index.html">Go to the home page</a></div>`;
  }

  /* ---------- boot ---------- */
  renderHeader(); renderFooter();
  if (params.get("logout")) toast("You're logged out");
  (pages[document.body.dataset.page] || pages.notfound)();
})();
